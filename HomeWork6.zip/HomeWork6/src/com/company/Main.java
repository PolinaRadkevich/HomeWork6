package com.company;


import com.company.Pupil.Pupil;


import java.util.*;

import static com.company.Pupil.Pupil.AgeComparator;
import static com.company.Pupil.Pupil.MarkComparator;

public class Main {

  public static void main(String[] args) {

    ArrayDeque<String> clients = new ArrayDeque<String>();
    clients.add("Иванов Иван Иванович client 1");
    clients.add("Петров Петр Петрович client 2");
    clients.add("Круглов Александр Александрович client 3");
    clients.add("Иванов Семен Иванович client 4");
    clients.add("Петров Иван Петрович client 5");
    clients.add("Круглов Борис Александрович client 6");
    clients.add("Грицевич Семен Иванович client 7");
    clients.add("Сидоров Иван Петрович client 8");
    clients.add("Романеня Борис Александрович client 9");

    System.out.println("Содержимое: " + clients);

    while (clients.peek() != null) {
      System.out.println(clients.pollFirst());
      System.out.println(clients.pollFirst());
      System.out.println(clients.pollLast());
    }

    LinkedList<String> list1 = new LinkedList<>();
    list1.add("Blue");
    list1.add("Red");
    list1.add("Yellow");
    list1.add("White");
    list1.add("Black");
    Collections.shuffle(list1);
    while (list1.size() > 0) {
      System.out.println(list1.pollLast());
    }

    System.out.println("##########1");

    LinkedList<String> list = new LinkedList<>();
    list.addFirst("Blue");
    list.addLast("Red");
    list.addFirst("Yellow");
    list.addLast("White");
    list.addFirst("Black");
    list.addLast("Orange");
    while (list.size() > 0) {
      System.out.println(list.pollLast());
      System.out.println(list.pollFirst());
    }
    System.out.println("####");
    LinkedList<String> list2 = new LinkedList<>();
    list2.add("Blue");
    list2.add("Red");
    list2.add("Yellow");
    list2.add("White");
    list2.add("Black");
    list2.add("Orange");

    for (int i = 0; i < 7; i++) {
      if (list2.get(i) != list2.getFirst() & list2.get(i) != list2.getLast()) {
        list2.addLast(list2.get(i));
        System.out.println(list2.getLast());
      }
    }
    System.out.println("############2");

    Set<Long> longBankCardNumber = new TreeSet<>();
    longBankCardNumber.add(1123581321345589L);
    longBankCardNumber.add(1245678910111213L);
    longBankCardNumber.add(1312111098765421L);
    longBankCardNumber.add(1312111098765421L);
    System.out.println(longBankCardNumber);

    Set<Integer> integerCargo = new TreeSet<>();
    integerCargo.add(100);
    integerCargo.add(200);
    integerCargo.add(150);
    integerCargo.add(50);
    integerCargo.add(70);
    int sum = 0;
    int sumDifference = 0;
    final int MAX_SUM = 500;

    for (int num : integerCargo) {
      sum = sum + num;
    }
    System.out.println("Сумма грузов: " + sum);

    if (sum > 500) {
      sumDifference = sum - MAX_SUM;
      System.out.println(sumDifference);
      Object o = ((TreeSet<Integer>) integerCargo).ceiling(sumDifference);
      System.out.println(o);
    } else {
      System.out.println("Места хватает");
    }

    Iterator<Integer> iterator = integerCargo.iterator();

    while (iterator.hasNext() == true) {
      System.out.println(iterator.next());
      iterator.remove();
      System.out.println(integerCargo);
    }
    System.out.println("###########3");

    Map<String, String> map = new HashMap<>();
    map.put("Sonia", "145_478po");
    map.put("Roma", "589ty145");
    map.put("Viktoria", "258_vic_258");
    map.put("Olga", "456ol789ga");
    System.out.println(map.get("Stepan"));
    map.put("Stepan", "478_178Stepan");
    System.out.println(map.containsKey("Stepan"));
    System.out.println(map.containsValue("145_478po"));
    System.out.println(map.remove("Roma"));
    System.out.println(map);

    System.out.println("###########4");

    Pupil[] empArr = new Pupil[6];
    empArr[0] = new Pupil("Иван", 7, 5);
    empArr[1] = new Pupil("Ольга", 8, 6);
    empArr[2] = new Pupil("Александр", 10, 7);
    empArr[3] = new Pupil("Матвей", 8, 9);
    empArr[4] = new Pupil("Роман", 7, 8);
    empArr[5] = new Pupil("Ирина", 9, 10);

    Arrays.sort(empArr);
    System.out.println(
        "Стандартная сортировка для массива объектов Employee:\n" + Arrays.toString(empArr));

    Arrays.sort(empArr, MarkComparator);
    System.out.println("Сортировка по оценке:\n" + Arrays.toString(empArr));

    Arrays.sort(empArr, AgeComparator);
    System.out.println("Сортировка по возрасту:\n" + Arrays.toString(empArr));
  }
}








