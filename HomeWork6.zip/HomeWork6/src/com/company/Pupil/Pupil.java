package com.company.Pupil;

import java.util.Objects;
import java.util.Comparator;

public class Pupil implements Comparable<Pupil> {

  private String name;
  private int age;
  private int mark;


  public Pupil(String name, int age, int mark) {
    this.name = name;
    this.age = age;
    this.mark = mark;
  }

  public String getName() {
    return name;
  }

  public int getAge() {
    return age;
  }

  public int getMark() {
    return mark;
  }

  public int compareTo(Pupil p) {

    return name.compareTo(p.getName());
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("Pupil{");
    sb.append("name='").append(name).append('\'');
    sb.append(", age=").append(age);
    sb.append(", mark=").append(mark);
    sb.append('}');
    return sb.toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Pupil)) {
      return false;
    }
    Pupil pupil = (Pupil) o;
    return getAge() == pupil.getAge() && getMark() == pupil.getMark() && Objects
        .equals(getName(), pupil.getName());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getName(), getAge(), getMark());
  }


  public static Comparator<Pupil> AgeComparator = new Comparator<Pupil>() {

    @Override
    public int compare(Pupil o1, Pupil o2) {
      return o1.getAge() - o2.getAge();
    }

    @Override
    public boolean equals(Object obj) {
      return false;
    }
  };


  public static Comparator<Pupil> MarkComparator = new Comparator<Pupil>() {
    @Override
    public int compare(Pupil o1, Pupil o2) {
      return o1.getMark() - o2.getMark();
    }

    @Override
    public boolean equals(Object obj) {
      return false;
    }
  };
}

